﻿Public Class frmEmployeelogin




    Private Sub btnnext_Click(sender As Object, e As EventArgs) Handles btnlogin.Click
        If txtusername.Text = "Employee" And txtpassword.Text = "1234" Then

            MessageBox.Show("Login Successful!")

            Me.Hide() 'Close the current form

            frmcustomerrecords.Show() 'Opens the new one

        Else

            MessageBox.Show("Incorrect login details, please try again")

            txtusername.Clear() 'Clears whats in the textbox

            txtpassword.Clear()

            txtusername.Focus() 'Puts the cursor back in this textbox, ready to type without having to click into it

        End If

    End Sub

    Private Sub txtusername_TextChanged(sender As Object, e As EventArgs) Handles txtusername.TextChanged

    End Sub

    Private Sub txtpassword_TextChanged(sender As Object, e As EventArgs) Handles txtpassword.TextChanged

    End Sub

    Private Sub btnclear_Click(sender As Object, e As EventArgs) Handles btnclear.Click

    End Sub

    Private Sub chkshowpassword_CheckedChanged(sender As Object, e As EventArgs) Handles chkshowpassword.CheckedChanged
        'If employee clicks this their passowrd becomes visible and if the unclick it their password is not visible
        If chkshowpassword.Checked = True Then
            txtpassword.UseSystemPasswordChar = False
        Else
            txtpassword.UseSystemPasswordChar = True
        End If
    End Sub
End Class
